# Portal Empleado Neovantas - Front adaptado

Este front adapta el HTML de referencia `preview (35).html` a una aplicación React + TypeScript + Vite con datos configurables en JSON.

## Qué incluye

- Header oscuro con marca Neovantas y sesión de usuario.
- Navegación superior por pestañas: Inicio, Herramientas IA, Recursos y herramientas, Documentación, Repositorios y Noticias.
- Home compacta con hero, buscador global, accesos rápidos, cinco bloques principales y últimos artículos.
- Cards reutilizables para herramientas, GPTs, recursos y repositorios.
- Buscador específico en Recursos y herramientas.
- Tabla de documentación preparada para conectar con SharePoint.
- Catálogo de repositorios preparado para futura conexión con SharePoint / Graph API.
- Datos separados en `/src/data/*.json`.

## Instalación

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Siguiente integración recomendada

1. Sustituir URLs placeholder por enlaces reales de SharePoint.
2. Conectar `documents.json` y `news.json` con los JSON generados por vuestros workflows.
3. Añadir autenticación Microsoft Entra ID en Azure Static Web Apps.
4. Publicar en Azure Static Web Apps con GitHub Actions.
5. Configurar dominio `portalempleado.neovantas.com`.

## Estructura de datos

- `quickLinks.json`: accesos rápidos del hero.
- `assistants.json`: GPTs y asistentes IA.
- `tools.json`: recursos y herramientas agrupables por categoría.
- `documents.json`: carpetas/documentación.
- `repositories.json`: repositorios de conocimiento.
- `news.json`: noticias y artículos.
