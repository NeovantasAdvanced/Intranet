import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Bot, BriefcaseBusiness, Building2, CalendarDays, ExternalLink, FileText, FolderOpen,
  Home, KeyRound, LayoutDashboard, Library, Lock, LogOut, Newspaper, Search, Sparkles,
  Users, X, ShieldCheck, Presentation, BarChart3, Image, Languages, BookOpen
} from 'lucide-react';
import './styles.css';
import quickLinks from './data/quickLinks.json';
import assistants from './data/assistants.json';
import tools from './data/tools.json';
import documents from './data/documents.json';
import repositories from './data/repositories.json';
import news from './data/news.json';

type Item = {
  id: string; title: string; description: string; url?: string; category?: string;
  status?: string; requiresVpn?: boolean; restricted?: boolean; color?: string; featured?: boolean;
  owner?: string; updatedAt?: string; source?: string; date?: string;
};

type TabId = 'inicio' | 'ai' | 'resources' | 'docs' | 'repos' | 'news';

const tabs: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: 'inicio', label: 'Inicio', icon: Home },
  { id: 'ai', label: 'Herramientas IA', icon: Bot },
  { id: 'resources', label: 'Recursos y herramientas', icon: LayoutDashboard },
  { id: 'docs', label: 'Documentación', icon: FileText },
  { id: 'repos', label: 'Repositorios', icon: FolderOpen },
  { id: 'news', label: 'Noticias', icon: Newspaper }
];

const iconMap: Record<string, React.ElementType> = {
  bot: Bot, users: Users, dashboard: LayoutDashboard, file: FileText, folder: FolderOpen, news: Newspaper,
  key: KeyRound, presentation: Presentation, chart: BarChart3, image: Image, translate: Languages,
  book: BookOpen, shield: ShieldCheck, briefcase: BriefcaseBusiness, building: Building2, calendar: CalendarDays,
  sparkles: Sparkles
};

function normalize(value: string) {
  return value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

function Header() {
  return <>
    <a href="#main-content" className="skip-link">Saltar al contenido principal</a>
    <header className="topbar">
      <div className="brand">
        <div className="brand-wordmark">NEOVANTAS</div>
        <div className="brand-separator" />
        <div className="header-sub">Portal de Recursos</div>
      </div>
      <div className="user-session">
        <div className="user-avatar">AA</div>
        <div className="user-info"><span className="user-name">AAnalytics</span><span className="user-role">Advanced Analytics</span></div>
        <button className="logout-btn"><LogOut size={14}/><span>Desconectar</span></button>
      </div>
    </header>
  </>;
}

function TabBar({ active, onChange }: { active: TabId; onChange: (id: TabId) => void }) {
  return <nav className="tab-bar" aria-label="Navegación principal">
    {tabs.map(t => {
      const Icon = t.icon;
      return <button key={t.id} className={`tab-btn ${active === t.id ? 'active' : ''}`} onClick={() => onChange(t.id)}>
        <Icon size={16}/>{t.label}
      </button>;
    })}
  </nav>;
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return <div className="section-header-with-action">
    <div className="section-header"><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>
    {action}
  </div>;
}

function SectionLabel({ children }: { children: React.ReactNode }) { return <div className="section-label">{children}</div>; }

function Badge({ item }: { item: Item }) {
  const classNames = ['tag', item.color || '', item.restricted ? 'tag--restricted' : ''].filter(Boolean).join(' ');
  return <span className={classNames}>{item.restricted && <Lock size={11}/>} {item.requiresVpn ? 'VPN requerida' : item.status || item.category || 'Activo'}</span>;
}

function ResourceCard({ item }: { item: Item }) {
  const Icon = iconMap[(item as any).icon] || ExternalLink;
  const content = <>
    <div className="card-icon"><Icon /></div>
    <div className="card-body"><div className="card-title">{item.title}</div><div className="card-desc">{item.description}</div></div>
    <div className="card-footer"><Badge item={item}/><span className="card-link">{item.url ? 'Abrir' : 'Solicitar acceso'} <ExternalLink size={14}/></span></div>
  </>;
  return item.url ? <a href={item.url} target="_blank" rel="noreferrer" className={`card ${item.featured ? 'featured-card' : ''}`}>{content}</a>
    : <article className="card card-static">{content}</article>;
}

function GlobalSearch({ allItems, onNavigate }: { allItems: (Item & { tab: TabId; tabLabel: string })[]; onNavigate: (tab: TabId) => void }) {
  const [query, setQuery] = useState('');
  const q = normalize(query);
  const matches = q.length < 2 ? [] : allItems
    .map(item => ({ item, score: normalize(`${item.title} ${item.description} ${item.category || ''}`).includes(q) ? 1 : 0 }))
    .filter(x => x.score > 0).slice(0, 8);
  return <div className="search-box home-search-box">
    <Search size={20}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar GPTs, documentos, aplicaciones o recursos..." />
    {query && <button className="clear-search visible" onClick={() => setQuery('')}><X size={14}/></button>}
    {q.length >= 2 && <div className="search-results visible">
      {matches.length === 0 ? <div className="search-empty">No se han encontrado resultados.</div> : matches.map(({ item }) => <button key={`${item.tab}-${item.id}`} className="search-result-item" onClick={() => item.url ? window.open(item.url, '_blank') : onNavigate(item.tab)}>
        <span><div className="search-result-meta">{item.tabLabel}</div><div className="search-result-title">{item.title}</div><div className="search-result-desc">{item.description}</div></span><span className="search-result-arrow">{item.url ? '↗' : '→'}</span>
      </button>)}
    </div>}
  </div>;
}

function Home({ onNavigate, allItems }: { onNavigate: (tab: TabId) => void; allItems: (Item & { tab: TabId; tabLabel: string })[] }) {
  const blocks = [
    { tab: 'ai' as TabId, title: 'Herramientas IA', icon: 'bot', text: 'Asistentes y GPTs internos para acelerar trabajo operativo y entregables.', links: assistants.slice(0, 2) as Item[], color: 'blue' },
    { tab: 'resources' as TabId, title: 'Recursos y herramientas', icon: 'dashboard', text: 'Aplicaciones internas, gestión, productividad, diseño y formación.', links: (tools as Item[]).slice(0, 2), color: 'purple' },
    { tab: 'docs' as TabId, title: 'Documentación', icon: 'file', text: 'Carpetas documentales, políticas, guías y materiales internos.', links: (documents as Item[]).slice(0, 2), color: 'green' },
    { tab: 'repos' as TabId, title: 'Repositorios', icon: 'folder', text: 'Acceso a conocimiento de banca y repositorio de proyectos.', links: repositories as Item[], color: 'orange' },
    { tab: 'resources' as TabId, title: 'KeePass', icon: 'key', text: 'Gestor seguro de contraseñas recomendado para proteger accesos y credenciales.', links: [{ id:'keepass', title:'Descargar KeePass', description:'', url:'#'}], color: 'teal', keepass: true }
  ];
  return <div className="home-shell">
    <section className="home-compact-hero">
      <div className="home-hero-copy">
        <span className="home-eyebrow">Portal de Recursos</span>
        <h1>El Workspace de Neovantas</h1>
        <p>Accede a los recursos más utilizados por bloque: asistentes IA, herramientas internas, documentación, repositorios y gestión segura de credenciales.</p>
        <GlobalSearch allItems={allItems} onNavigate={onNavigate}/>
      </div>
      <aside className="home-quick-side">
        <div className="home-side-title">Accesos rápidos</div>
        {(quickLinks as Item[]).slice(0,5).map(link => <a className="home-side-link" href={link.url} target="_blank" rel="noreferrer" key={link.id}>{link.title}<span>↗</span></a>)}
      </aside>
    </section>
    <div className="home-blocks-header"><div><h2>Bloques principales</h2><p>Una vista rápida de los cinco accesos operativos más importantes del portal.</p></div></div>
    <section className="home-blocks-row">
      {blocks.map(block => { const Icon = iconMap[block.icon]; return <article className={`home-block-card ${block.keepass ? 'keepass-home-card' : ''}`} key={block.title}>
        <div className="home-block-top"><div className={`module-icon ${block.color}`}><Icon /></div>{!block.keepass && <button className="home-block-open" onClick={() => onNavigate(block.tab)}>Ver pestaña →</button>}</div>
        <h3>{block.title}</h3><p>{block.text}</p>
        <div className="home-block-links">{block.links.map(l => l.url ? <a href={l.url} target="_blank" rel="noreferrer" key={l.id}>{l.title}</a> : <button key={l.id} onClick={() => onNavigate(block.tab)}>{l.title}</button>)}</div>
      </article>; })}
    </section>
    <section className="home-news-section widget">
      <div className="widget-title home-articles-title"><BookOpen size={16}/>Últimos artículos<button onClick={() => onNavigate('news')} className="section-action">Ver todos</button></div>
      {(news as Item[]).slice(0,1).map(item => <article className="article-featured" key={item.id}><div className="article-kicker">Artículo destacado</div><h3>{item.title}</h3><p>{item.description}</p><div className="article-meta"><span>{item.category}</span><span>·</span><span>{item.date}</span><span>·</span><span>{item.source}</span></div></article>)}
      {(news as Item[]).slice(1,3).map(item => <article className="article-card-mini" key={item.id}><h4>{item.title}</h4><p>{item.category} · {item.date}</p></article>)}
    </section>
  </div>;
}

function AiPage() { return <><SectionHeader title="Herramientas de Inteligencia Artificial" subtitle="Acceso centralizado a las plataformas de IA disponibles en Neovantas" action={<a className="keepass-mini"><KeyRound size={14}/>Descargar KeePass</a>}/><SectionLabel>Plataformas y GPTs especializados</SectionLabel><div className="cards-grid">{(assistants as Item[]).map(item => <ResourceCard item={item} key={item.id}/>)}</div></>; }

function ResourcesPage() {
  const [query, setQuery] = useState('');
  const q = normalize(query);
  const list = (tools as Item[]).filter(item => !q || normalize(`${item.title} ${item.description} ${item.category}`).includes(q));
  const groups = ['Herramientas de gestión','Herramientas de trabajo y productividad','Cuadros de mando','Diseño y recursos gráficos','Contenido interactivo y formación','Productividad y referencia'];
  return <><SectionHeader title="Recursos y herramientas" subtitle="Plataformas y servicios digitales disponibles para el equipo de Neovantas" action={<a className="keepass-mini"><KeyRound size={14}/>Descargar KeePass</a>}/>
    <div className="resources-search-panel"><div className="resources-search-title"><Search size={15}/>Buscar recursos</div><div className="resources-search-box"><Search size={15}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar herramienta..."/>{query && <button className="resources-clear-search visible" onClick={() => setQuery('')}>×</button>}</div><div className="resources-search-meta">{query ? `${list.length} resultados encontrados.` : 'Busca por nombre, categoría o descripción.'}</div></div>
    {groups.map(group => { const items = list.filter(i => i.category === group); return items.length ? <React.Fragment key={group}><SectionLabel>{group}</SectionLabel><div className="cards-grid">{items.map(item => <ResourceCard item={item} key={item.id}/>)}</div></React.Fragment> : null; })}
  </>;
}

function DocsPage() { return <><SectionHeader title="Documentación Interna" subtitle="Acceso a las carpetas principales de documentación interna de Neovantas."/><div className="repo-disclaimer"><strong>Ilustrativo · pendiente de conectar:</strong> esta sección está preparada para conectarse a SharePoint / Graph API.</div><SectionLabel>Carpetas documentales</SectionLabel><div className="widget doc-directory"><table className="doc-table"><thead><tr><th>Documento</th><th>Área</th><th>Actualización</th><th>Acceso</th></tr></thead><tbody>{(documents as Item[]).map(item => <tr key={item.id}><td><div className="doc-row-title"><div className="doc-icon"><FileText size={18}/></div><div><strong>{item.title}</strong><br/><span>{item.description}</span></div></div></td><td><span className="tag">{item.category}</span></td><td>{item.updatedAt || 'General'}</td><td>{item.url ? <a href={item.url}>Abrir carpeta →</a> : <a>Abrir carpeta →</a>}</td></tr>)}</tbody></table></div></>; }

function ReposPage() { return <><SectionHeader title="Repositorios" subtitle="Acceso centralizado a repositorios de conocimiento y proyectos."/><SectionLabel>Repositorios disponibles</SectionLabel><div className="cards-grid">{(repositories as Item[]).map(item => <ResourceCard item={item} key={item.id}/>)}</div><SectionLabel>Catálogo de recursos</SectionLabel><div className="repo-disclaimer"><strong>Ilustrativo · pendiente de conectar:</strong> este bloque muestra cómo se visualizará el catálogo cuando esté conectado a SharePoint / repositorios reales.</div><div className="repo-catalog"><div className="repo-catalog-head"><div className="repo-catalog-title"><Library/><div><strong>Catálogo de recursos</strong><span>Vista ilustrativa de recursos indexados</span></div></div><div className="repo-controls"><button className="repo-filter active">Equipo</button><button className="repo-filter">Proyectos</button><button className="repo-filter">Ficheros</button><button className="repo-filter">Docs finales</button></div></div><div className="repo-metrics"><div className="repo-metric"><div className="repo-metric-value">94</div><div className="repo-metric-label">Recursos</div></div><div className="repo-metric"><div className="repo-metric-value">33</div><div className="repo-metric-label">Proyectos</div></div><div className="repo-metric"><div className="repo-metric-value">22</div><div className="repo-metric-label">Fichas</div></div><div className="repo-metric"><div className="repo-metric-value">20</div><div className="repo-metric-label">Docs finales</div></div></div></div></>; }

function NewsPage() { const groups = Array.from(new Set((news as Item[]).map(n => n.category || 'General'))); return <><SectionHeader title="Noticias del Sector" subtitle="Artículos y novedades relevantes sobre IA, consultoría, comportamiento del consumidor y tecnología"/>{groups.map(group => <React.Fragment key={group}><SectionLabel>{group}</SectionLabel><div className="cards-grid">{(news as Item[]).filter(n => n.category === group).map(item => <article className="news-card" key={item.id}><div className="news-card-meta"><span className="tag">{item.category}</span><span className="news-card-date">{item.date}</span></div><div className="news-card-title">{item.title}</div><div className="news-card-excerpt">{item.description}</div><div className="news-card-source">{item.source} →</div></article>)}</div></React.Fragment>)}</>; }

function App() {
  const [active, setActive] = useState<TabId>('inicio');
  const allItems = useMemo(() => [
    ...(assistants as Item[]).map(i => ({...i, tab: 'ai' as TabId, tabLabel:'Herramientas IA'})),
    ...(tools as Item[]).map(i => ({...i, tab: 'resources' as TabId, tabLabel:'Recursos y herramientas'})),
    ...(documents as Item[]).map(i => ({...i, tab: 'docs' as TabId, tabLabel:'Documentación'})),
    ...(repositories as Item[]).map(i => ({...i, tab: 'repos' as TabId, tabLabel:'Repositorios'})),
    ...(news as Item[]).map(i => ({...i, tab: 'news' as TabId, tabLabel:'Noticias'}))
  ], []);
  return <><Header/><TabBar active={active} onChange={setActive}/><main id="main-content">{active === 'inicio' && <Home onNavigate={setActive} allItems={allItems}/>} {active === 'ai' && <AiPage/>}{active === 'resources' && <ResourcesPage/>}{active === 'docs' && <DocsPage/>}{active === 'repos' && <ReposPage/>}{active === 'news' && <NewsPage/>}</main></>;
}

createRoot(document.getElementById('root')!).render(<App/>);
